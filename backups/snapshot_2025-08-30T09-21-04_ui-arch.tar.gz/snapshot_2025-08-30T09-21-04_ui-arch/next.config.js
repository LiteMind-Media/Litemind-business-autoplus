/**
 * Next.js configuration in plain JavaScript so production runtime
 * doesn't require installing TypeScript just to parse next.config.
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  // Add config options here as needed
};

module.exports = nextConfig;
