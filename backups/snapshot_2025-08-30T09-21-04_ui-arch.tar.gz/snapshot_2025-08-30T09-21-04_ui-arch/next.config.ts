// Placeholder file intentionally left empty to avoid requiring TypeScript at runtime.
// Use next.config.js instead. Keeping this file (empty) prevents accidental recreation.
export {};
